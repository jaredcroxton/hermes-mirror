# Specialist-agent governance cleanup and routing registry

Use this when Jared asks to clean up the Hermes specialist-agent ecosystem, move profile-local SOUL files into Obsidian, remove stale duplicate profiles, or create a routing registry.

## Pattern used successfully

1. Inspect profiles and SOUL source of truth:

```bash
hermes profile list
python - <<'PY'
from pathlib import Path
profiles = ['bobbuilder','nellynotebook','laralearning','samstudynerd','pollyperformos','harryhr']
for name in profiles:
    d = Path('/Users/jc/.hermes/profiles') / name
    s = d / 'SOUL.md'
    print(name, 'exists=', d.exists(), 'soul=', s.exists(), 'symlink=', s.is_symlink(), 'target=', s.resolve() if s.exists() else '')
PY
```

2. If a rich profile-local SOUL is more current than the Obsidian version, back up the Obsidian file first, then promote the profile SOUL into Obsidian.

3. Replace profile `SOUL.md` with a symlink to the canonical Obsidian SOUL.

4. Remove stale duplicate profiles only after confirming they have no SOUL/config/env worth preserving.

5. Create or update:

`/Users/jc/Desktop/Obsidian/Agents/Agent Registry.md`

Include for each agent:

- role
- profile
- alias
- Telegram bot
- SOUL path
- runtime state
- handoff rule
- quality/review gates

6. Verify:

```bash
hermes profile list
readlink /Users/jc/.hermes/profiles/<profile>/SOUL.md
```

Restart any running profile gateway whose SOUL/config changed.

## Governance rule

SOUL files hold identity, boundaries, decision rules, output contracts, and quality gates.

Skills hold repeatable procedures.

Obsidian is the canonical source for important agent SOUL files.

## Pitfall

Do not assume a profile should be started as a Telegram gateway until its profile-local `.env` has a unique `TELEGRAM_BOT_TOKEN`. Reusing another agent's token causes bot identity confusion and polling conflict.