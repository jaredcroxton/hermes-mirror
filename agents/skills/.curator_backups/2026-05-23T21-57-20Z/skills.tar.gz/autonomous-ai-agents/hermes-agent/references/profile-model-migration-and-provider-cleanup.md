# Profile model migration and provider cleanup

Use this when Jared asks to move all specialist agents to a different model/provider or remove a provider such as Grok/xAI from the stack.

## Key lesson

Do not bulk-change every profile to a model name before verifying that the active provider/account can actually access it. A model can appear plausible but fail at runtime with HTTP 404 or unsupported-model errors.

## Safe sequence

1. Check current profile state:
   ```bash
   hermes profile list
   hermes status --all
   hermes auth list
   ```

2. Identify available auth. For Jared's current no-extra-API-cost ChatGPT path, the working provider is usually `openai-codex`, not OpenAI API key access.

3. Probe candidate models before rollout:
   ```bash
   for m in gpt-5.4 gpt-5.3-codex gpt-5 gpt-5-mini; do
     echo "Testing $m"
     hermes chat -q "Reply exactly OK" --provider openai-codex -m "$m" --quiet 2>&1 | head -20
     echo "---"
   done
   ```

4. Only after one model replies successfully, apply it:
   ```bash
   profiles="atticuscounsel bobbuilder harryhr laralearning nellynotebook pollyperformos samstudynerd"
   hermes config set model.default "gpt-5.4"
   hermes config set model.provider "openai-codex"
   for p in $profiles; do
     hermes --profile "$p" config set model.default "gpt-5.4"
     hermes --profile "$p" config set model.provider "openai-codex"
   done
   ```

5. Restart gateways/handlers and verify with direct profile tests:
   ```bash
   hermes --profile bobbuilder chat -q "Reply exactly BOB_OK" --quiet
   hermes --profile pollyperformos chat -q "Reply exactly POLLY_OK" --quiet
   ```

## Removing Grok/xAI links

Search active configs and auth files:
```bash
grep -Rni "grok\|xai" ~/.hermes/config.yaml ~/.hermes/profiles/*/config.yaml ~/.hermes/auth.json ~/.hermes/profiles/*/auth.json 2>/dev/null || true
```

Places where Grok/xAI may remain after changing `model.default`:
- profile `model.provider: xai-oauth`
- profile `model.base_url: https://api.x.ai/v1`
- `auxiliary.image_gen.provider: xai`
- `auxiliary.image_gen.model: grok-2-image`
- `providers.xai` or `providers.xai-oauth`
- `tts.xai`
- `x_search.model: grok-...`
- `platform_toolsets` containing `x_search`
- `plugins.enabled` containing `image_gen/xai`
- `auth.json` provider or credential pool entries for `xai-oauth`

Back up files before programmatic cleanup. After cleanup, grep again and run profile direct tests.

## Pitfalls

- `gpt-5.5` can fail with HTTP 404 under a team/account even if it looks like a valid future model name. Verify first.
- A ChatGPT/Codex subscription route is not the same as an OpenAI API key route. If there is no `OPENAI_API_KEY`, prefer `openai-codex` only if `hermes auth list` shows valid OpenAI Codex OAuth.
- Profile-local `auth.json` files can have stale or consumed Codex tokens. If main profile works and specialist profiles fail with missing/consumed Codex credentials, copy a cleaned main `auth.json` into profile auth files after backing up, removing unwanted provider entries such as `xai-oauth`.
- `hermes profile list` gateway status can lag behind live processes. Confirm with process checks or direct profile queries before declaring a gateway dead.
- For Atticus, the custom Telegram handler is separate from standard profile gateway status. Restart the handler separately.
