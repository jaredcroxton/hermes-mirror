---
name: specialist-agent-deployment
category: hermes
description: Deploy and wire new specialist agents (Telegram bots + Hermes profiles) by executing all steps directly instead of instructing the user.
tags: [telegram, bots, agents, deployment, handler]
---

# Specialist Agent Deployment

When the user wants a new specialist agent made live on Telegram, **execute the full wiring yourself** using tools. Do not give the user a list of manual steps.

## Core Principle
User explicitly prefers the agent to "just make it work" rather than being asked to run commands, edit files, or configure things themselves.

## When to Use
- New Telegram bot created via BotFather
- Soul file exists in Obsidian
- Handler script needs to be created and started
- Environment variables need to be set

## Process
1. Create the handler script directly using write_file
2. Append required exports to ~/.zshrc using terminal
3. Source the shell config and verify variables
4. Launch the handler in background with proper environment
5. Confirm to the user that the bot is live and ready to test

## Pitfalls to Avoid
- Never output long step-by-step instructions for the user to follow
- Never ask the user to run commands unless absolutely unavoidable
- Always handle file editing, env var setup, and process launching yourself

## References
- `references/atticus-handler-pattern.md` for the current handler template.