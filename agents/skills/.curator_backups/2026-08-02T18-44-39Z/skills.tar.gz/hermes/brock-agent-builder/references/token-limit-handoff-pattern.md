# Token-Limit Handoff Pattern

When Claude Code hits token limits mid-build, do not try to cram everything into the remaining tokens. Save a handoff and resume in a fresh chat.

## The handoff prompt

```
Save a context handoff to .claude/crew-state/brock-handoff.md.

State: CREW skill upgrades in progress. [Pack name] currently being upgraded. [X] of [Y] gold so far. [Current skill] upgrade prompt is running — do not re-send it.

Completed:
- [skill 1] ✅
- [skill 2] ✅

Remaining:
- [skill A] (5 sections)
- [skill B] (5 sections)

Source files: /Users/jc/Desktop/cluade/crew-skill-packs/packs/[pack]/

Standard upgrade pattern for every skill:
1. Read source completely and reference benchmark (nearest completed skill in same pack)
2. Add Discovery section after role paragraph, 6 gold-standard sections
3. Promote buried Workflow content into ## reference sections (domain-specific, 4-5 per skill)
4. Step 0 reads brand-context + own handoff. Output header and context loop per skill.
5. Fixture A/B/C. Adversarial review (3 lenses: harness, white-label, senior domain expert). Apply all findings.
6. QA: bash shared/qa-check.sh --pack [pack]. Report old size, new size, sections, QA result.

Standing rule: no package/plugin/PDF/commit until all packs final.
```

## Resume prompt

In the fresh chat, first message:

```
Read .claude/crew-state/brock-handoff.md and pick up where I left off.
```

## Rules

- Always note which skill is currently building — do not re-send its prompt
- Include the standard upgrade pattern in the handoff so the fresh chat knows the workflow
- Include the standing rule (no package/plugin/PDF/commit)
- Source file paths are absolute
- The handoff file lives in `.claude/crew-state/` — the same directory brand-context.md lives in

## Pitfalls

- Do not assume the fresh chat will remember conversation context. The handoff must be self-contained.
- Do not use Desktop as the handoff point. Claude Code reliably reads from `.claude/crew-state/`.
- Verify the fresh chat actually read the handoff before continuing.
